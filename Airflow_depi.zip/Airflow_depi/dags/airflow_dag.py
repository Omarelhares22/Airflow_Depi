from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import random

# Define the DAG
with DAG(
    dag_id='Airflow_Depi_Omar_Mostafa',
    start_date=datetime(2025, 10, 5),
    schedule_interval=timedelta(minutes=1),
    catchup=False
) as dag:

    # Task 1: Print current date using BashOperator
    task1_print_date = BashOperator(
        task_id='print_current_date',
        bash_command='date'
    )

    # Task 2: Print welcome message using PythonOperator
    def print_welcome_message():
        print("Welcome to Airflow, Omar Mostafa!")

    task2_welcome_message = PythonOperator(
        task_id='print_welcome_message',
        python_callable=print_welcome_message
    )

    # Task 3: Generate random number and save to /tmp/random.txt
    def generate_random_number():
        random_num = random.randint(1, 100)
        with open('/tmp/random.txt', 'w') as f:
            f.write(str(random_num))
        print(f"Generated random number: {random_num}")

    task3_generate_random = PythonOperator(
        task_id='generate_random_number',
        python_callable=generate_random_number
    )

    # Set task dependencies: Task 1 → Task 2 → Task 3
    task1_print_date >> task2_welcome_message >> task3_generate_random